package com.example.eva3_3_interfaz_grafica;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity
implements RadioGroup.OnCheckedChangeListener {

    RadioGroup rdEstadoCivil;

    Button btnNomCom;
    EditText edtTxtNom, edtTxtApe;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //View es una clase, son la base de todos los componentes gráficos en Android.
        //Es un área rectangular donde se dibuja algo
        rdEstadoCivil = findViewById(R.id.RadioGrp);
        btnNomCom = findViewById(R.id.btnNomCom);
        edtTxtApe = findViewById(R.id.edtTxtApe);
        edtTxtNom = findViewById(R.id.edtTxtNom);
        //Vincular eventos: igual que en Java ---> listeners
        rdEstadoCivil.setOnCheckedChangeListener(this);
        btnNomCom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nombre = edtTxtNom.getText().toString();
                String apellido = edtTxtApe.getText().toString();
                Toast.makeText(MainActivity.this, nombre + " " + apellido, Toast.LENGTH_SHORT).show();
                //Para cerrar la actividad -----> finish();

            }
        });
    }

    @Override
    public void onCheckedChanged(RadioGroup radioGroup, int i) {

        if (i == R.id.RbtnSoltero) {
            Toast.makeText(this, "Soltero", Toast.LENGTH_SHORT).show();

            if (i == R.id.RbtnCasado) {
                Toast.makeText(this, "Casado", Toast.LENGTH_SHORT).show();

                if (i == R.id.RbtnViudo) {
                    Toast.makeText(this, "Viudo", Toast.LENGTH_SHORT).show();

                    if (i == R.id.RbtnUnionlibre) {
                        Toast.makeText(this, "Unión Libre :D", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }
    }
}