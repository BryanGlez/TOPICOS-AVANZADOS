/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author bryan
 */
public class MisLibrerias {
    public static int calculaFacto(int valor){
        int facto = 1;
        for (int i = 1; i <= valor; i++){
            //facto = facto * 1;
            facto*=i;
        }
        return facto;
    }    
    
}
